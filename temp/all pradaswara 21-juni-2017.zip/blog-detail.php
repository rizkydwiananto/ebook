<?php

//WEB TITLE
$title ="Blog - Pradaswara Website";
$description ="";
$author ="";

//LAYOUT
$page ="blog";

$main_dir = "Our Blog";
$sub_dir = "Article";
$sub_dir_2 ="Judul Blog";





?>
<!DOCTYPE html>
<html lang="en">
  <head>
	  <?php include"layout/all-head.php"; ?>
  </head>
  <body>
	  
	
<?php 
//HEADER
include"layout/all-header.php";  
include"layout/all-heading-blue.php";  
include"layout/blog-detail-konten.php";  

  ?>	

	  <?php
//FOOTER
include"layout/all-footer.php";  

	  ?>	
	
	</body>
</html>