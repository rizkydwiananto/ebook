	<div class="gallery-home mt50">
		<div class="container">
			<div class="row">
				<div class="heading-1">
					<h1>Gallery</h1>
				</div>
				<div class="content">
				<div id="owl-gallery-home" class="owl-carousel owl-theme">
					<div class="item">
						<img src="images/home/gallery/gallery-assets-01.png" class="img-thumbnail">
					</div>
					<div class="item">
						<img src="images/home/gallery/gallery-assets-02.png" class="img-thumbnail">
					</div>
					<div class="item">
						<img src="images/home/gallery/gallery-assets-blank.png" class="img-thumbnail">
					</div>
					<div class="item">
						<img src="images/home/gallery/gallery-assets-01.png" class="img-thumbnail">
					</div>
					<div class="item">
						<img src="images/home/gallery/gallery-assets-02.png" class="img-thumbnail">
					</div>
					<div class="item">
						<img src="images/home/gallery/gallery-assets-blank.png" class="img-thumbnail">
					</div>

				</div>					
					
				</div>
			</div>
		  </div>
	</div>	  
