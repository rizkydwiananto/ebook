<div class="services-top">
	<div class="container-fluid">
		<div class="row">
			<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
				<!-- Indicators -->
				<ol class="carousel-indicators hidden-xs">
					<li data-target="#carousel-example-generic" data-slide-to="0" class="active">
						<div class="sgt"></div>
						<div class="icon-pic"><img src="images/services/wd.png"></div>
						<div class="indikator-caption"><p>Merchandise</p></div>
					</li>
					<li data-target="#carousel-example-generic" data-slide-to="1">
						<div class="sgt"></div>
						<div class="icon-pic"><img src="images/services/gd.png"></div>
						<div class="indikator-caption"><p>Offset & Digital Print</p></div>
					</li>
					<li data-target="#carousel-example-generic" data-slide-to="2">
						<div class="sgt"></div>
						<div class="icon-pic"><img src="images/services/id.png"></div>
						<div class="indikator-caption"><p>Loremp Ipsum</p></div>
					</li>
					<li data-target="#carousel-example-generic" data-slide-to="3">
						<div class="sgt"></div>
						<div class="icon-pic"><img src="images/services/wd.png"></div>
						<div class="indikator-caption"><p>Loremp Ipsum</p></div>
					</li>
					<li data-target="#carousel-example-generic" data-slide-to="4">
						<div class="sgt"></div>
						<div class="icon-pic"><img src="images/services/wd.png"></div>
						<div class="indikator-caption"><p>Loremp Ipsum</p></div>
					</li>
					
				</ol>
				<div class="heading-services">
					<h2>Bisnis Utama</h2>
				</div>
				<!-- Wrapper for slides -->
				<div class="carousel-inner" role="listbox">
					<div class="item active">
						<img src="images/services/Slider/slide-services-01.png" alt="..." style="width:100%;">
						<div class="carousel-caption">
							<h3>Fabrication</h3>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras tempus bibendum venenatis. Duis in iaculis risus, sed luctus felis. Curabitur id diam eget orci semper facilisis et a nulla.</p>
						</div>
					</div>
					<div class="item">
						<img src="images/services/Slider/slide-services.png" alt="..." style="width:100%;">
						<div class="carousel-caption">
							<h3>Fabrication</h3>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras tempus bibendum venenatis. Duis in iaculis risus, sed luctus felis. Curabitur id diam eget orci semper facilisis et a nulla.</p>

						</div>
					</div>
					<div class="item">
						<img src="images/services/Slider/slide-services.png" alt="..." style="width:100%;">
						<div class="carousel-caption">
							<h3>Fabrication</h3>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras tempus bibendum venenatis. Duis in iaculis risus, sed luctus felis. Curabitur id diam eget orci semper facilisis et a nulla.</p>

						</div>
					</div>
					<div class="item">
						<img src="images/services/Slider/slide-services.png" alt="..." style="width:100%;">
						<div class="carousel-caption">
							<h3>Fabrication</h3>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras tempus bibendum venenatis. Duis in iaculis risus, sed luctus felis. Curabitur id diam eget orci semper facilisis et a nulla.</p>

						</div>
					</div>
					<div class="item">
						<img src="images/services/Slider/slide-services.png" alt="..." style="width:100%;">
						<div class="carousel-caption">
							<h3>Fabrication</h3>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras tempus bibendum venenatis. Duis in iaculis risus, sed luctus felis. Curabitur id diam eget orci semper facilisis et a nulla.</p>

						</div>
					</div>
					
				</div>

			</div>
		</div>
	</div>

</div>