<div class="blog">
	<div class="container">
		<div class="row">
			<!--Blog Timeline-->

			<div class="col-md-9">

				<!--itemnya mas-->
				<div class="blog-item">
					<div class="garis-vertical-dotted"></div>
					<div class="garis-horizontal-dotted"></div>
					<div class="timeline-date">
						08
						<br><span>June</span>
					</div>
					<div class="row">
						<div class="timeline-pic col-md-4">
							<img src="images/blog/thumb-400/thumb400-blur.jpg">
						</div>
						<div class="timeline-isi col-md-8">
							<h2 class="blog-title">Judul Blognya ini Bosku</h2>
							<ul class="blog-info">
								<li>
									<p><i class="fa fa-calendar-o" aria-hidden="true"></i> Kamis, 8 June 2017</p>
								</li>
								<li>
									<p><i class="fa fa-folder-open-o" aria-hidden="true"></i> Article</p>
								</li>
								<li>
									<p><i class="fa fa-user" aria-hidden="true"></i> Admin</p>
								</li>
							</ul>
							<p class="blog-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras tempus bibendum venenatis. Duis in iaculis risus, sed luctus felis. Curabitur id diam eget orci semper facilisis et a nulla. Duis et efficitur urna, ac...</p>
							<a href="blog-detail.php" class="btn btn-primary">Read More</a>
						</div>
					</div>
					<hr>
				</div>
				<!--itemnya mas-->
				<div class="blog-item">
					<div class="garis-vertical-dotted"></div>
					<div class="garis-horizontal-dotted"></div>
					<div class="timeline-date">
						08
						<br><span>June</span>
					</div>
					<div class="row">
						<div class="timeline-pic col-md-4">
							<img src="images/blog/thumb-400/thumb400-blur.jpg">
						</div>
						<div class="timeline-isi col-md-8">
							<h2 class="blog-title">Judul Blognya ini Bosku</h2>
							<ul class="blog-info">
								<li>
									<p><i class="fa fa-calendar-o" aria-hidden="true"></i> Kamis, 8 June 2017</p>
								</li>
								<li>
									<p><i class="fa fa-folder-open-o" aria-hidden="true"></i> Article</p>
								</li>
								<li>
									<p><i class="fa fa-user" aria-hidden="true"></i> Admin</p>
								</li>
							</ul>
							<p class="blog-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras tempus bibendum venenatis. Duis in iaculis risus, sed luctus felis. Curabitur id diam eget orci semper facilisis et a nulla. Duis et efficitur urna, ac...</p>
							<a href="blog-detail.php" class="btn btn-primary">Read More</a>
						</div>
					</div>
					<hr>
				</div>
				<!--itemnya mas-->
				<div class="blog-item">
					<div class="garis-vertical-dotted"></div>
					<div class="garis-horizontal-dotted"></div>
					<div class="timeline-date">
						08
						<br><span>June</span>
					</div>
					<div class="row">
						<div class="timeline-pic col-md-4">
							<img src="images/blog/thumb-400/thumb400-blur.jpg">
						</div>
						<div class="timeline-isi col-md-8">
							<h2 class="blog-title">Judul Blognya ini Bosku</h2>
							<ul class="blog-info">
								<li>
									<p><i class="fa fa-calendar-o" aria-hidden="true"></i> Kamis, 8 June 2017</p>
								</li>
								<li>
									<p><i class="fa fa-folder-open-o" aria-hidden="true"></i> Article</p>
								</li>
								<li>
									<p><i class="fa fa-user" aria-hidden="true"></i> Admin</p>
								</li>
							</ul>
							<p class="blog-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras tempus bibendum venenatis. Duis in iaculis risus, sed luctus felis. Curabitur id diam eget orci semper facilisis et a nulla. Duis et efficitur urna, ac...</p>
							<a href="blog-detail.php" class="btn btn-primary">Read More</a>
						</div>
					</div>
					<hr>
				</div>
				<!--itemnya mas-->
				<div class="blog-item">
					<div class="garis-vertical-dotted"></div>
					<div class="garis-horizontal-dotted"></div>
					<div class="timeline-date">
						08
						<br><span>June</span>
					</div>
					<div class="row">
						<div class="timeline-pic col-md-4">
							<img src="images/blog/thumb-400/thumb400-blur.jpg">
						</div>
						<div class="timeline-isi col-md-8">
							<h2 class="blog-title">Judul Blognya ini Bosku</h2>
							<ul class="blog-info">
								<li>
									<p><i class="fa fa-calendar-o" aria-hidden="true"></i> Kamis, 8 June 2017</p>
								</li>
								<li>
									<p><i class="fa fa-folder-open-o" aria-hidden="true"></i> Article</p>
								</li>
								<li>
									<p><i class="fa fa-user" aria-hidden="true"></i> Admin</p>
								</li>
							</ul>
							<p class="blog-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras tempus bibendum venenatis. Duis in iaculis risus, sed luctus felis. Curabitur id diam eget orci semper facilisis et a nulla. Duis et efficitur urna, ac...</p>
							<a href="blog-detail.php" class="btn btn-primary">Read More</a>
						</div>
					</div>
					<hr>
				</div>
				<!--itemnya mas-->
				<div class="blog-item">
					<div class="garis-vertical-dotted"></div>
					<div class="garis-horizontal-dotted"></div>
					<div class="timeline-date">
						08
						<br><span>June</span>
					</div>
					<div class="row">
						<div class="timeline-pic col-md-4">
							<img src="images/blog/thumb-400/thumb400-blur.jpg">
						</div>
						<div class="timeline-isi col-md-8">
							<h2 class="blog-title">Judul Blognya ini Bosku</h2>
							<ul class="blog-info">
								<li>
									<p><i class="fa fa-calendar-o" aria-hidden="true"></i> Kamis, 8 June 2017</p>
								</li>
								<li>
									<p><i class="fa fa-folder-open-o" aria-hidden="true"></i> Article</p>
								</li>
								<li>
									<p><i class="fa fa-user" aria-hidden="true"></i> Admin</p>
								</li>
							</ul>
							<p class="blog-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras tempus bibendum venenatis. Duis in iaculis risus, sed luctus felis. Curabitur id diam eget orci semper facilisis et a nulla. Duis et efficitur urna, ac...</p>
							<a href="blog-detail.php" class="btn btn-primary">Read More</a>
						</div>
					</div>
					<hr>
				</div>

				<!--Pagination-->
				<center>
					<nav aria-label="Page navigation">
						<ul class="pagination">
							<li>
								<a href="#" aria-label="Previous">
									<span aria-hidden="true">&laquo;</span>
								</a>
							</li>
							<li class="active"><a href="#">1</a></li>
							<li><a href="#">2</a></li>
							<li><a href="#">3</a></li>
							<li><a href="#">4</a></li>
							<li><a href="#">5</a></li>
							<li>
								<a href="#" aria-label="Next">
									<span aria-hidden="true">&raquo;</span>
								</a>
							</li>
						</ul>
					</nav>
				</center>


			</div>



			<!--Widget-->
			<div class="col-md-3">
			
							<!-- side navigation -->
							<div class="kategori">

								<div class="kategori-head">
									<h4>CATEGORIES</h4>
								</div>
								<ul class="list-kategori">
									<li class="list-item"><a href="#"><span class="pull-right">(12)</span> MEDIA</a></li>
									<li class="list-item"><a href="#"><span class="pull-right">(8)</span> MOVIES</a></li>
									<li class="list-item active"><a href="#"><span class="pull-right">(8)</span> article</a></li>
									<li class="list-item"><a href="#"><span class="pull-right">(32)</span> NEW</a></li>
									<li class="list-item"><a href="#"><span class="pull-right">(16)</span> TUTORIALS</a></li>
									<li class="list-item"><a href="#"><span class="pull-right">(2)</span> DEVELOPMENT</a></li>
									<li class="list-item"><a href="#"><span class="pull-right">(1)</span> UNCATEGORIZED</a></li>

								</ul>
								<!-- /side navigation -->
							</div>
				
				
				<?php include"widget.php";?>
			
			</div>
		</div>
	</div>
</div>