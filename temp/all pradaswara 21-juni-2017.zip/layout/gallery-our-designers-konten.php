<div class="gallery-designer">

	<div class="icon-kiri">
		<div class="">
			<div class="row">
				<div class="icon">
					<a href="gallery-our-designer-dtl.php"><img src="images/gallery/designers/gd.png"></a>
				</div>				
				<div class="gd-isi">
					<h3>Graphic Design</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras tempus bibendum venenatis. Duis in iaculis risus, sed luctus felis. Curabitur id diam eget orci semper facilisis et a nulla. Duis et efficitur urna, ac </p>
					<a href="gallery-our-designer-dtl.php">Read More...</a>
				</div>
			</div>
		</div>
	</div>

	<div class="icon-kanan">
		<div class="">
			<div class="row">
				<div class="icon">
					<a href="gallery-our-designer-dtl.php"><img src="images/gallery/designers/wd.png"></a>
				</div>
				<div class="gd-isi">
					<h3>Web Design</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras tempus bibendum venenatis. Duis in iaculis risus, sed luctus felis. Curabitur id diam eget orci semper facilisis et a nulla. Duis et efficitur urna, ac </p>
					<a href="gallery-our-designer-dtl.php">Read More...</a>
				</div>
			</div>
		</div>
	</div>

	<div class="icon-kiri">
		<div class="">
			<div class="row">
				<div class="icon">
					<a href="gallery-our-designer-dtl.php"><img src="images/gallery/designers/gd.png"></a>
				</div>				
				<div class="gd-isi">
					<h3>Graphic Design</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras tempus bibendum venenatis. Duis in iaculis risus, sed luctus felis. Curabitur id diam eget orci semper facilisis et a nulla. Duis et efficitur urna, ac </p>
					<a href="gallery-our-designer-dtl.php">Read More...</a>
				</div>
			</div>
		</div>
	</div>

	<div class="icon-kanan">
		<div class="">
			<div class="row">
				<div class="icon">
					<a href="gallery-our-designer-dtl.php"><img src="images/gallery/designers/wd.png"></a>
				</div>
				<div class="gd-isi">
					<h3>Web Design</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras tempus bibendum venenatis. Duis in iaculis risus, sed luctus felis. Curabitur id diam eget orci semper facilisis et a nulla. Duis et efficitur urna, ac </p>
					<a href="gallery-our-designer-dtl.php">Read More...</a>
				</div>
			</div>
		</div>
	</div>

</div>