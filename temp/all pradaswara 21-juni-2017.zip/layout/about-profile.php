	<div class="profile">
		<div class="container">
			<div class="row">
				<center>
					<img src="images/logo/color.png">
					<div class="profile-text mt50">
						<p>Berawal dari percetakan biasa seiring dengan meningkatnya kepercayaan pelanggan pada tahun 2008 legalitas perusahaan dibukukan dalam lembar negara. Pengembangan dilakukan sebagai jawaban dari permintaan pelanggan dalam memenuhi berbagai kebutuhan promosi saat itu.</p>
						<p>Kini PT.Krakatoa Pradaswara telah mampu mengembangkan usahanya ke berbagai lini dalam pemenuhan jasa dan barang barang promosi seperti ofsset & Digital Printing, Konveksi, Merchandise, Signed,  dan Kontraktor Exhibition</p>
					</div>
				</center>
			</div>
		  </div>
	</div>	  
