<div class="gallery-designer">
	<div class="container gallery-detail">
		<div class="row">
			
			<!--KONTEN-->
			<div class="col-md-9">
			
				<!--Item-->
				<div class="designer-item row">
					<div class="designer-pic">
						<img src="images/gallery/designers/person.png" class="designer name">
					</div>
					<div class="designer-info">
						<h4>Designer Name's</h4>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras tempus bibendum venenatis. Duis in iaculis risus, sed luctus felis. Curabitur id diam eget orci semper facilisis et a nulla. Duis et efficitur urna, ac </p>
						<a href="#">Download CV</a>
					</div>
					<hr>
				</div>
				<!--Item-->
				<div class="designer-item row">
					<div class="designer-pic">
						<img src="images/gallery/designers/person.png" class="designer name">
					</div>
					<div class="designer-info">
						<h4>Designer Name's</h4>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras tempus bibendum venenatis. Duis in iaculis risus, sed luctus felis. Curabitur id diam eget orci semper facilisis et a nulla. Duis et efficitur urna, ac </p>
						<a href="#">Download CV</a>
					</div>
					<hr>
				</div>
				<!--Item-->
				<div class="designer-item row">
					<div class="designer-pic">
						<img src="images/gallery/designers/person.png" class="designer name">
					</div>
					<div class="designer-info">
						<h4>Designer Name's</h4>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras tempus bibendum venenatis. Duis in iaculis risus, sed luctus felis. Curabitur id diam eget orci semper facilisis et a nulla. Duis et efficitur urna, ac </p>
						<a href="#">Download CV</a>
					</div>
					<hr>
				</div>
				<!--Item-->
				<div class="designer-item row">
					<div class="designer-pic">
						<img src="images/gallery/designers/person.png" class="designer name">
					</div>
					<div class="designer-info">
						<h4>Designer Name's</h4>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras tempus bibendum venenatis. Duis in iaculis risus, sed luctus felis. Curabitur id diam eget orci semper facilisis et a nulla. Duis et efficitur urna, ac </p>
						<a href="#">Download CV</a>
					</div>
					<hr>
				</div>
				<!--Item-->
				<div class="designer-item row">
					<div class="designer-pic">
						<img src="images/gallery/designers/person.png" class="designer name">
					</div>
					<div class="designer-info">
						<h4>Designer Name's</h4>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras tempus bibendum venenatis. Duis in iaculis risus, sed luctus felis. Curabitur id diam eget orci semper facilisis et a nulla. Duis et efficitur urna, ac </p>
						<a href="#">Download CV</a>
					</div>
					<hr>
				</div>
				<!--Item-->
				<div class="designer-item row">
					<div class="designer-pic">
						<img src="images/gallery/designers/person.png" class="designer name">
					</div>
					<div class="designer-info">
						<h4>Designer Name's</h4>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras tempus bibendum venenatis. Duis in iaculis risus, sed luctus felis. Curabitur id diam eget orci semper facilisis et a nulla. Duis et efficitur urna, ac </p>
						<a href="#">Download CV</a>
					</div>
					<hr>
				</div>
				
				
				<!--Pagination-->
				<center>
					<nav aria-label="Page navigation">
						<ul class="pagination">
							<li>
								<a href="#" aria-label="Previous">
									<span aria-hidden="true">&laquo;</span>
								</a>
							</li>
							<li class="active"><a href="#">1</a></li>
							<li><a href="#">2</a></li>
							<li><a href="#">3</a></li>
							<li><a href="#">4</a></li>
							<li><a href="#">5</a></li>
							<li>
								<a href="#" aria-label="Next">
									<span aria-hidden="true">&raquo;</span>
								</a>
							</li>
						</ul>
					</nav>
				</center>				
			</div>
			
			
			<!--WIDGET-->
			<div class="col-md-3">
				<?php include"widget.php";?>
			</div>
		
		</div>
	</div>


</div>