<div class="services-quotes">
	<div class="container">
		<div class="row">
			<div class="col-md-8 col-md-offset-4">
				<div id="owl-services-quotes" class="owl-carousel owl-theme">
					
					<!--item-->
					<div class="item row">
						<div class="pic"><img src="images/services/Capture.PNG"></div>
						<div class="text">
							<p class="top">"The best ideas come as jokes. Make your thinking as funny as possible."</p>
							<p class="mid">"Ide-ide yang terbaik datang sebagai lelucon. Buatlah pikiran Anda sejenaka mungkin."</p>
							<p class="bot">-David Ogilvy-</p>
						</div>
					</div>
					<!--item-->
					<div class="item row">
						<div class="pic"><img src="images/services/Capture.PNG"></div>
						<div class="text">
							<p class="top">"The best ideas come as jokes. Make your thinking as funny as possible."</p>
							<p class="mid">"Ide-ide yang terbaik datang sebagai lelucon. Buatlah pikiran Anda sejenaka mungkin."</p>
							<p class="bot">-David Ogilvy-</p>
						</div>
					</div>
					<!--item-->
					<div class="item row">
						<div class="pic"><img src="images/services/Capture.PNG"></div>
						<div class="text">
							<p class="top">"The best ideas come as jokes. Make your thinking as funny as possible."</p>
							<p class="mid">"Ide-ide yang terbaik datang sebagai lelucon. Buatlah pikiran Anda sejenaka mungkin."</p>
							<p class="bot">-David Ogilvy-</p>
						</div>
					</div>
					
				</div>

			</div>
			<br>
		</div>
	</div>
</div>