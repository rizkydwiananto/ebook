	<div class="misi">
		<div class="container">
			<div class="row">
				<h2>Our Mision</h2>
				<div class="misi-text">

					<div class="col-md-6"></div>
					<div class="col-md-6">
						<ul class="mt50">
							<li>Menjalin kemitraan dalam dan luar negeri dalam melengkapi permintaan terhadap kebutuhan barang dan jasa khususnya dibidang promosi</li>
							<li>Menjadi pelopor dan pencipta kreasi produk-produk promosi</li>
							<li>Memberikan pengalaman pelayanan terbaik dan terpercaya terhadap seluruh pelanggan</li>
							<li>Menjadi perusahan  yang mendunia dan tetap berpegang pada kearifan lokal</li>
							
						</ul>
		
					</div>
					<div class="bg2 hidden-xs"><img src="images/about_us/misi/mission-bg.png" class="img-responsive"></div>
				</div>
			</div>
		  </div>
	</div>	  
