	<div class="heading-blue mt70">
		<div class="container">
			<div class="row">
				<div class="orange-blue" ><img src="images/O-Krakatoa-100px.png" class="animated rotateIn"></div>
				<ul class="dir" >
					<li class="sub-dir  animated bounceIn"><a href="#"><?php echo"$main_dir"; ?></a></li>
					<li class="sub-dir  animated bounceIn" <?php if (empty($sub_dir)){ echo"style=\"display:none;\"";}?> ><a href="#"><?php echo"$sub_dir"; ?></a></li>
					<li class="sub-dir  animated bounceIn" <?php if (empty($sub_dir_2)){ echo"style=\"display:none;\"";}?> ><a href="#"><?php echo"$sub_dir_2"; ?></a></li>
					
				</ul>
				
			</div>
		  </div>
	</div>	  
