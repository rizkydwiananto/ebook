<div class="gallery-product mt50">
	<div class="container">
		<div class="row">
			<div class="col-md-3">
				<div class="product-kategori">
					<div class="title">
						<h4>Kategori</h4>
					</div>

					<ul>
						<li class="list-kategori"><a href="#">Branding </a></li>
						<li class="list-kategori active"><a href="#">Pabrikasi Gantungan Kunci & Rubber </a></li>
						<li class="list-kategori"><a href="#">Pabrikasi Topi Promosi </a></li>
						<li class="list-kategori"><a href="#">Pabrikasi Payung Promosi </a></li>
						<li class="list-kategori"><a href="#">Pabrikasi Payung Promosi </a></li>
						<li class="list-kategori"><a href="#">Pabrikasi Payung Promosi </a></li>

					</ul>
				</div>
			</div>
			<div class="col-md-9">
				<div class="title">
					<h4>Pabrikasi Gantungan Kunci & Rubber</h4>
				</div>
				<div class="gallery-pic-list">

					<!--ITEM-->
					<div class="col-md-3 item">
						<a href="images/gallery/pic/ori/model%201.jpg" title="Judul gambare mas">
							<img src="images/gallery/pic/thumb-300/model%201.jpg">
							<span><i class="fa fa-search-plus"></i></span>
						</a>
					</div>
					<!--ITEM-->
					<div class="col-md-3 item">
						<a href="images/gallery/pic/ori/model%202.jpg" title="Judul gambare mas">
							<img src="images/gallery/pic/thumb-300/model%202.jpg">
							<span><i class="fa fa-search-plus"></i></span>
						</a>
					</div>
					<!--ITEM-->
					<div class="col-md-3 item">
						<a href="images/gallery/pic/ori/model%203.jpg" title="Judul gambare mas">
							<img src="images/gallery/pic/thumb-300/model%203.jpg">
							<span><i class="fa fa-search-plus"></i></span>
						</a>
					</div>
					<!--ITEM-->
					<div class="col-md-3 item">
						<a href="images/gallery/pic/ori/model%204.jpg" title="Judul gambare mas">
							<img src="images/gallery/pic/thumb-300/model%204.jpg">
							<span><i class="fa fa-search-plus"></i></span>
						</a>
					</div>
					<!--ITEM-->
					<div class="col-md-3 item">
						<a href="images/gallery/pic/ori/model%205.jpg" title="Judul gambare mas">
							<img src="images/gallery/pic/thumb-300/model%205.jpg">
							<span><i class="fa fa-search-plus"></i></span>
						</a>
					</div>
					<!--ITEM-->
					<div class="col-md-3 item">
						<a href="images/gallery/pic/ori/model%201.jpg" title="Judul gambare mas">
							<img src="images/gallery/pic/thumb-300/model%201.jpg">
							<span><i class="fa fa-search-plus"></i></span>
						</a>
					</div>
					<!--ITEM-->
					<div class="col-md-3 item">
						<a href="images/gallery/pic/ori/model%201.jpg" title="Judul gambare mas">
							<img src="images/gallery/pic/thumb-300/model%201.jpg">
							<span><i class="fa fa-search-plus"></i></span>
						</a>
					</div>
					<!--ITEM-->
					<div class="col-md-3 item">
						<a href="images/gallery/pic/ori/model%201.jpg" title="Judul gambare mas">
							<img src="images/gallery/pic/thumb-300/model%201.jpg">
							<span><i class="fa fa-search-plus"></i></span>
						</a>
					</div>
					<!--ITEM-->
					<div class="col-md-3 item">
						<a href="images/gallery/pic/ori/model%201.jpg" title="Judul gambare mas">
							<img src="images/gallery/pic/thumb-300/model%201.jpg">
							<span><i class="fa fa-search-plus"></i></span>
						</a>
					</div>
					<!--ITEM-->
					<div class="col-md-3 item">
						<a href="images/gallery/pic/ori/model%201.jpg" title="Judul gambare mas">
							<img src="images/gallery/pic/thumb-300/model%201.jpg">
							<span><i class="fa fa-search-plus"></i></span>
						</a>
					</div>
					<!--ITEM-->
					<div class="col-md-3 item">
						<a href="images/gallery/pic/ori/model%201.jpg" title="Judul gambare mas">
							<img src="images/gallery/pic/thumb-300/model%201.jpg">
							<span><i class="fa fa-search-plus"></i></span>
						</a>
					</div>
					<!--ITEM-->
					<div class="col-md-3 item">
						<a href="images/gallery/pic/ori/model%201.jpg" title="Judul gambare mas">
							<img src="images/gallery/pic/thumb-300/model%201.jpg">
							<span><i class="fa fa-search-plus"></i></span>
						</a>
					</div>
					<!--ITEM-->
					<div class="col-md-3 item">
						<a href="images/gallery/pic/ori/model%201.jpg" title="Judul gambare mas">
							<img src="images/gallery/pic/thumb-300/model%201.jpg">
							<span><i class="fa fa-search-plus"></i></span>
						</a>
					</div>
					<!--ITEM-->
					<div class="col-md-3 item">
						<a href="images/gallery/pic/ori/model%201.jpg" title="Judul gambare mas">
							<img src="images/gallery/pic/thumb-300/model%201.jpg">
							<span><i class="fa fa-search-plus"></i></span>
						</a>
					</div>
					<!--ITEM-->
					<div class="col-md-3 item">
						<a href="images/gallery/pic/ori/model%201.jpg" title="Judul gambare mas">
							<img src="images/gallery/pic/thumb-300/model%201.jpg">
							<span><i class="fa fa-search-plus"></i></span>
						</a>
					</div>
					<!--ITEM-->
					<div class="col-md-3 item">
						<a href="images/gallery/pic/ori/model%201.jpg" title="Judul gambare mas">
							<img src="images/gallery/pic/thumb-300/model%201.jpg">
							<span><i class="fa fa-search-plus"></i></span>
						</a>
					</div>

				</div>

				<!--Pagination-->
				<center>
					<nav aria-label="Page navigation">
						<ul class="pagination">
							<li>
								<a href="#" aria-label="Previous">
									<span aria-hidden="true">&laquo;</span>
								</a>
							</li>
							<li class="active"><a href="#">1</a></li>
							<li><a href="#">2</a></li>
							<li><a href="#">3</a></li>
							<li><a href="#">4</a></li>
							<li><a href="#">5</a></li>
							<li>
								<a href="#" aria-label="Next">
									<span aria-hidden="true">&raquo;</span>
								</a>
							</li>
						</ul>
					</nav>
				</center>

			</div>


		</div>
	</div>
</div>
<script>
	$(document).ready(function () {
		$('.gallery-pic-list').magnificPopup({
			delegate: 'a',
			type: 'image',
			closeOnContentClick: false,
			closeBtnInside: false,
			mainClass: 'mfp-with-zoom mfp-img-mobile',
			image: {
				verticalFit: true,
				titleSrc: function (item) {
					return item.el.attr('title') + ' &middot; <a class="image-source-link" href="' + item.el.attr('data-source') + '" target="_blank">image source</a>';
				}
			},
			gallery: {
				enabled: true
			},
			zoom: {
				enabled: true,
				duration: 300, // don't foget to change the duration also in CSS
				opener: function (element) {
					return element.find('img');
				}
			}

		});
	});
</script>