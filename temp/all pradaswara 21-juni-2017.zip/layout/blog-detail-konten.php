<div class="blog-detail">
	<div class="container">
		<div class="row">
			<!--Blog Timeline-->

			<div class="col-md-9">

				<div class="konten">
					<div class="head-title">
						<h1 class="blog-title">Judul Blognya ini Bosku</h1>
						<ul class="blog-info">
							<li>
								<p><i class="fa fa-calendar-o" aria-hidden="true"></i> Kamis, 8 June 2017</p>
							</li>
							<li>
								<p><i class="fa fa-folder-open-o" aria-hidden="true"></i> Article</p>
							</li>
							<li>
								<p><i class="fa fa-user" aria-hidden="true"></i> Admin</p>
							</li>
						</ul>
					</div>
					<div class="detail-pic">
						<a class="blog-detail-img-zoom" href="images/blog/ori/blur.jpg" title="Captionnya ditulis disini mas.">
							<img src="images/blog/thumb-400/thumb400-blur.jpg">
						</a>
					</div>
					<div class="blog-text mt30">
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eget scelerisque nunc. Maecenas quis urna ultrices, euismod lectus eget, pulvinar est. Maecenas non diam blandit, iaculis lacus eget, ornare mi. Praesent elementum ipsum leo, sit amet ullamcorper nunc fringilla nec. Mauris id diam ullamcorper, tincidunt tellus ut, interdum leo. Fusce a consequat sapien. Etiam lacus ipsum, rutrum eu sollicitudin at, pharetra sed tellus.
						</p>
						<p>Vivamus rhoncus lorem vel suscipit efficitur. Nam iaculis lectus quis mauris lacinia, eget cursus ex volutpat. Donec vitae dui ex. Pellentesque feugiat lorem nec metus tincidunt, quis aliquet est rutrum. Donec et risus gravida, venenatis quam id, cursus nisl. Aliquam erat volutpat. Integer efficitur ut quam sed sagittis. Donec diam mauris, varius sed nibh ut, blandit ultrices ipsum. Donec bibendum orci mattis, pellentesque magna interdum, pellentesque magna. Pellentesque at mi eu odio efficitur malesuada. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae;
						</p>
						<p>In massa leo, faucibus et lorem sed, convallis luctus ipsum. Etiam mattis tellus eu purus posuere, ut volutpat enim laoreet. Cras nisl sapien, aliquet hendrerit ligula a, tincidunt tempor ante. Curabitur mattis non ante vitae congue. Vivamus id cursus nisi. Donec consectetur rutrum sem et ornare. Duis sapien eros, dictum eget mi at, volutpat bibendum nulla. Praesent ac nibh nec orci condimentum scelerisque. Nulla tincidunt ipsum viverra velit gravida, vitae commodo leo rutrum. Vivamus cursus, orci non rutrum scelerisque, nulla sapien varius nunc, et malesuada magna nisl in mauris.
						</p>
						<p>Praesent ut ullamcorper velit, ac pulvinar massa. Vestibulum quis semper erat, sed maximus odio. Donec et libero fringilla, tincidunt purus nec, cursus ante. Donec consectetur elit sit amet tincidunt sodales. Aenean vel urna nisl. Etiam aliquet justo vitae enim feugiat aliquam. Pellentesque ipsum elit, rutrum vitae cursus sit amet, consectetur ut quam. In dictum nisl lobortis, rutrum massa in, tempus justo. Suspendisse sollicitudin et sapien sed porta. Maecenas eget feugiat urna. Donec a scelerisque mi. Ut laoreet justo odio, at consectetur felis blandit elementum. Sed sollicitudin turpis ultrices rutrum consectetur.
						</p>
						<p>Vivamus at ex lacinia, auctor velit quis, tincidunt arcu. Quisque gravida imperdiet nisi. Ut sit amet pretium leo. Donec ultricies, sapien nec auctor congue, augue lacus pulvinar augue, sed fermentum tellus dui vitae ex. Curabitur maximus vel quam quis tempor. Vivamus quis risus sit amet mauris ullamcorper pellentesque. Sed et velit tincidunt, porta turpis a, tincidunt magna. Nullam ligula justo, cursus nec risus in, vehicula malesuada sapien. Suspendisse enim lectus, imperdiet ac elit vel, malesuada dictum arcu. Integer imperdiet blandit ultricies. Nullam vel est ac purus ornare facilisis id at turpis. Donec eu finibus ex, sit amet pretium lectus. Nam consectetur euismod leo non tincidunt. In hac habitasse platea dictumst.
						</p>
						<p>Donec ullamcorper, justo et euismod euismod, risus risus luctus justo, vitae euismod velit dolor in leo. Fusce id tincidunt mi. Curabitur ultricies egestas nisi ut consectetur. Praesent convallis est non tincidunt ullamcorper. Proin tellus sapien, laoreet nec magna sit amet, vulputate dapibus tellus. Sed purus eros, placerat eget cursus sit amet, pellentesque vel ligula. Pellentesque posuere risus nunc, a auctor tortor rutrum at. Mauris mollis volutpat quam vel accumsan. Maecenas purus enim, gravida vitae suscipit ut, sagittis non enim. Curabitur consequat neque sed massa tincidunt ornare. Donec ac aliquam risus. In convallis pretium magna et fermentum. Quisque vulputate vehicula lectus, non accumsan tellus pulvinar a. Nulla volutpat urna at aliquet viverra.
						</p>
						<p>Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; In feugiat tincidunt pellentesque. Aliquam ultricies leo quis augue vehicula condimentum. Cras arcu odio, facilisis id ex ac, iaculis maximus leo. Sed augue magna, interdum in commodo at, luctus bibendum eros. Nunc a nisi eu lacus lobortis tincidunt. Nam eros diam, convallis in neque in, tempus venenatis mauris. Phasellus vehicula dapibus neque, ac varius urna mollis id. Aliquam vitae libero et enim consectetur eleifend. Integer ante nulla, sodales id aliquam a, imperdiet eget nulla. Nullam massa nulla, ultricies at vulputate sit amet, rhoncus in diam.
					</div>
				</div>

			</div>



			<!--Widget-->
			<div class="col-md-3">

				<!-- side navigation -->
				<div class="kategori">

					<div class="kategori-head">
						<h4>CATEGORIES</h4>
					</div>
					<ul class="list-kategori">
						<li class="list-item"><a href="#"><span class="pull-right">(12)</span> MEDIA</a></li>
						<li class="list-item"><a href="#"><span class="pull-right">(8)</span> MOVIES</a></li>
						<li class="list-item active"><a href="#"><span class="pull-right">(8)</span> article</a></li>
						<li class="list-item"><a href="#"><span class="pull-right">(32)</span> NEW</a></li>
						<li class="list-item"><a href="#"><span class="pull-right">(16)</span> TUTORIALS</a></li>
						<li class="list-item"><a href="#"><span class="pull-right">(2)</span> DEVELOPMENT</a></li>
						<li class="list-item"><a href="#"><span class="pull-right">(1)</span> UNCATEGORIZED</a></li>

					</ul>
					<!-- /side navigation -->
				</div>
				<?php include"widget.php";?>				


			</div>
		</div>
	</div>
</div>
<script>
	$(document).ready(function () {
		$('.blog-detail-img-zoom').magnificPopup({
			type: 'image',
			closeOnContentClick: true,
			closeBtnInside: false,
			fixedContentPos: true,
			mainClass: 'mfp-no-margins mfp-with-zoom', // class to remove default margin from left and right side
			image: {
				verticalFit: true
			},
			zoom: {
				enabled: true,
				duration: 300 // don't foget to change the duration also in CSS
			}
		});
	});
</script>