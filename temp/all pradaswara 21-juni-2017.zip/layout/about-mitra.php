	<div class="mitra">
		<h2><span>Mitra Kami</span></h2>
		
		<div class="container">
			<div class="row">
				<div class="mitra-icon">
				<center>
					<div class="col-md-3 col-sm-3 col-xs-6 item">
						<img src="images/about_us/logo_client/Angkasa%20Pura%201%20png.png" class="img-responsive">
					</div>
					<div class="col-md-3 col-sm-3 col-xs-6 item">
						<img src="images/about_us/logo_client/BCAinsurance%20png.png" class="img-responsive">
					</div>
					<div class="col-md-3 col-sm-3 col-xs-6 item">
						<img src="images/about_us/logo_client/BTPN%20png.png" class="img-responsive">
					</div>
					<div class="col-md-3 col-sm-3 col-xs-6 item">
						<img src="images/about_us/logo_client/Danareksa%20png.png" class="img-responsive">
					</div>
					<div class="col-md-3 col-sm-3 col-xs-6 item">
						<img src="images/about_us/logo_client/Generali%20png.png" class="img-responsive">
					</div>
					<div class="col-md-3 col-sm-3 col-xs-6 item">
						<img src="images/about_us/logo_client/Household-Interior-icon.png" class="img-responsive">
					</div>
					<div class="col-md-3 col-sm-3 col-xs-6 item">
						<img src="images/about_us/logo_client/Kementerian%20Agama%20png.png" class="img-responsive">
					</div>
					<div class="col-md-3 col-sm-3 col-xs-6 item">
						<img src="images/about_us/logo_client/Kementerian%20Perhubungan%20png.png" class="img-responsive">
					</div>
					<div class="col-md-3 col-sm-3 col-xs-6 item">
						<img src="images/about_us/logo_client/Kenso%20png.png" class="img-responsive">
					</div>
					<div class="col-md-3 col-sm-3 col-xs-6 item">
						<img src="images/about_us/logo_client/Rockstar%20Gym%20png.png" class="img-responsive">
					</div>
					<div class="col-md-3 col-sm-3 col-xs-6 item">
						<img src="images/about_us/logo_client/Sahabat%20Cipta%20png.png" class="img-responsive">
					</div>
					<div class="col-md-3 col-sm-3 col-xs-6 item">
						<img src="images/about_us/logo_client/SouthPole%20png.png" class="img-responsive">
					</div>
					<div class="col-md-3 col-sm-3 col-xs-6 item">
						<img src="images/about_us/logo_client/SwissContact%20png.png" class="img-responsive">
					</div>
					<div class="col-md-3 col-sm-3 col-xs-6 item">
						<img src="images/about_us/logo_client/USAID%20png.png" class="img-responsive">
					</div>
					
				</center>
				</div>
			</div>
		  </div>
	</div>	  
