<div class="contact-konten">
	<div class="container">
		<div class="row">
			<h2 class="title">OUR CONTACT & ADDRESS</h2>
			<div class="isi-kontak">
				<div class="col-md-7">
					<div class="map">
						<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3965.6727036515845!2d106.75400731476955!3d-6.306660995435663!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69efda2b18eeb1%3A0xe3bea9346241f122!2sUniversitas+Islam+Negeri+Syarif+Hidayatullah+-+Kampus+1!5e0!3m2!1sid!2sid!4v1497587210440" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
				
					</div>
				</div>
				<div class="col-md-5">
					<table style="width:100%">
						<tr>
							<td class="contact-isi"><p>Marketing Office</p></td>
							<td class="contact-isian">
								<p>Jl. Peninggaran Timur II No.6 RT.05/09 Kebayoran Lama Jakarta Selatan 12240, Jakarta, Indonesia</p>
							</td>
						</tr>
						<tr>
							<td class="contact-isi"><p>Phone</p></td>
							<td class="contact-isian">
								<p>62-21 72895245</p>
							</td>
						</tr>
						<tr>
							<td class="contact-isi"><p>Fax</p></td>
							<td class="contact-isian">
								<p>62-21 7238409</p>
							</td>
						</tr>
						<tr>
							<td class="contact-isi"><p>Mobile</p></td>
							<td class="contact-isian">
								<p>0878 7131 0145</p>
							</td>
						</tr>
						<tr>
							<td class="contact-isi"><p>Emails</p></td>
							<td class="contact-isian">
								<p>krakatoa@pradaswara.com</p>
								<p>a-f@pradaswara.com</p>
								<p>finance@pradaswara.com</p>
								<p>purchase@pradaswara.com</p>
								<p>produksi@pradaswara.com</p>
								
							</td>
						</tr>


					</table>
				</div>
			</div>
		</div>
	</div>
</div>