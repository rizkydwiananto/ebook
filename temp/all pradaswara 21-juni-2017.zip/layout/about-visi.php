	<div class="visi">
		<div class="container">
			<div class="row">
				<h2>Our Vision</h2>
				<div class="visi-text">
					<center>
					<div class="col-md-6"><p><i>"Memberikan pelayanan tanpa batas untuk memenuhi kebutuhan barang dan jasa di bidang  promosi"</i></p></div>
					<div class="col-md-6"><img src="images/about_us/visi/new.png"></div>
					</center>
				</div>
			</div>
		  </div>
	</div>	  
