	<div class="our-blog-home mt50">
		<div class="container">
			<div class="row">
				<h1>Our Blog</h1>
				<div class="col-md-6">
					<div class="our-blog-list">
						<div class="our-blog-item mt20">
							<h3><a href="#">Loremp ipsum dolor sit amet</a></h3>
							<p><span>Rabu, 14 Juni 2017</span></p>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce arcu dolor, ultricies eget sodales non, congue quis dui. Nullam a.....</p>
						</div>
						<div class="our-blog-item mt20">
							<h3><a href="#">Loremp ipsum dolor sit amet</a></h3>
							<p><span>Rabu, 14 Juni 2017</span></p>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce arcu dolor, ultricies eget sodales non, congue quis dui. Nullam a.....</p>
						</div>
						<div class="our-blog-item mt20">
							<h3><a href="#">Loremp ipsum dolor sit amet</a></h3>
							<p><span>Rabu, 14 Juni 2017</span></p>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce arcu dolor, ultricies eget sodales non, congue quis dui. Nullam a.....</p>
						</div>
						
						<p class="more mt30"><a href="#">More...</a></p>
					</div>
				</div>
				<div class="col-md-6">
					<div class="our-blog-pic">
						<div class="our-blog-item mt20">
							<img src="images/home/blog-asset-blank.png" class="img-responsive">
						</div>
						<div class="our-blog-item mt20">
							<img src="images/home/blog-asset-blank.png" class="img-responsive">
						</div>
						
					</div>
				</div>
			</div>
		  </div>
	</div>	
