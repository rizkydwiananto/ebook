<div class="home-slider">
	<div class="container-fluid">
		<div class="row">
			<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
				<!-- Indicators -->
				<ol class="carousel-indicators">
					<li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
					<li data-target="#carousel-example-generic" data-slide-to="1"></li>
				</ol>

				<!-- Wrapper for slides -->
				<div class="carousel-inner" role="listbox">
					<div class="item active">
						<img src="images/home/slider/one.png" alt="..." style="width:100%;">
						<div class="carousel-caption">
							<h3>Fabrication</h3>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras tempus bibendum venenatis. Duis in iaculis risus, sed luctus felis. Curabitur id diam eget orci semper facilisis et a nulla.</p>
						</div>
					</div>
					<div class="item">
						<img src="images/home/slider/one.png" alt="..." style="width:100%;">
						<div class="carousel-caption">
							<h3>Fabrication</h3>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras tempus bibendum venenatis. Duis in iaculis risus, sed luctus felis. Curabitur id diam eget orci semper facilisis et a nulla.</p>

						</div>
					</div>
				</div>

			</div>
		</div>
	</div>
</div>