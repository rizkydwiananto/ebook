<div class="bisnis-pendukung mt50">
	<div class="container">
		<div class="row">
			<h2>Bisnis Pendukung</h2>
			<div class="bisnis-pendukung-text">
				<div class="pic-list">
					<div class="col-md-3">
						<div class="item">
							<img src="images/services/pic/thumb-300/model%201.jpg">
							<div class="caption">
								<p>Loremp Ipsum Satu</p>
							</div>
						</div>
					</div>
					<div class="col-md-3 ">
						<div class="item">
							<img src="images/services/pic/thumb-300/model%202.jpg">
							<div class="caption">
								<p>Loremp Ipsum Satu</p>
							</div>							
						</div>
					</div>
					<div class="col-md-3 ">
						<div class="item">
							<img src="images/services/pic/thumb-300/model%203.jpg">
							<div class="caption">
								<p>Loremp Ipsum Satu</p>
							</div>							
						</div>
					</div>
					<div class="col-md-3 ">
						<div class="item">
							<img src="images/services/pic/thumb-300/model%204.jpg">
							<div class="caption">
								<p>Loremp Ipsum Satu</p>
							</div>							
						</div>
					</div>
					<div class="col-md-3 ">
						<div class="item">
							<img src="images/services/pic/thumb-300/model%205.jpg">
							<div class="caption">
								<p>Loremp Ipsum Satu hoho hshs hsogfd </p>
							</div>							
						</div>
					</div>
					<div class="col-md-3 ">
						<div class="item">
							<img src="images/services/pic/thumb-300/model%201.jpg">
							<div class="caption">
								<p>Loremp Ipsum Satu</p>
							</div>							
						</div>
					</div>
					<div class="col-md-3 ">
						<div class="item">
							<img src="images/services/pic/thumb-300/model%202.jpg">
							<div class="caption">
								<p>Loremp Ipsum Satu</p>
							</div>							
						</div>
					</div>
					<div class="col-md-3 ">
						<div class="item">
							<img src="images/services/pic/thumb-300/model%203.jpg">
							<div class="caption">
								<p>Loremp Ipsum Satu</p>
							</div>							
						</div>
					</div>

				</div>
			</div>
		</div>
	</div>
</div>