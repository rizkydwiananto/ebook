<footer>
	<div class="container">
		<div class="row">
			<div class="col-md-4">
				<img src="images/logo/light.png" class="logo">
					<div class="contact mt20">
						<div class="social-icon">
							<ul>
								<li><a href="#"  style="background:#3B5998"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
								<li><a href="#"  style="background:#cb0451"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
								<li><a href="#"  style="background:#00ACEE"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
								<li><a href="#"  style="background:#DD4B39"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
								<li><a href="#"  style="background:#0E76A8"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
							
							</ul>
						</div>
						<p>Phone/ Fax : 62-21 72895245/ 62-21 7238409 </p>
						<p>Mail : krakatoa@pradaswara.com</p>
					</div>					
				<p class="mt20">Aliquam in nulla vehicula metus placerat maximus eget in nibh. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce congue est ac erat sollicitudin, id hendrerit augue ultrices. Nullam leo nisi, dictum eu lorem et, accumsan ultrices nisl. Suspendisse vel sodales tortor. Donec luctus feugiat consequat. Cras mattis vitae ipsum ut dictum</p>
			</div>
			<div class="col-md-4 link-f">
				<ul class="link-footer">
					<li><a href="#">About Us</a></li>
					<li><a href="#">Service</a></li>
					<li><a href="#">Our Product</a></li>
					<li><a href="#">Our Designer</a></li>
					<li><a href="#">Blog</a></li>
				</ul>
			</div>
			<div class="col-md-4">
				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3965.652198796672!2d106.75409371436338!3d-6.309340995433753!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69efda2b18eeb1%3A0xe3bea9346241f122!2sUniversitas+Islam+Negeri+Syarif+Hidayatullah+-+Kampus+1!5e0!3m2!1sid!2sid!4v1497391141957" width="400" height="300" frameborder="0" style="border:0" allowfullscreen></iframe>
			</div>
			
		</div>
	</div>
	<div class="copyright mt20">&copy;2017 <a href="#"> Krakatoa</a> All Right Reserved.</div>
</footer>
