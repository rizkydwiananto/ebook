	<div class="services mt50">
		<div class="container">
			<div class="row">
				<h1>Services</h1>
				<div id="owl-services" class="owl-carousel owl-theme">
					<div class="item">
						<div class="col-md-6 col-xs-12">
							<div class="box-service-1">
								<img src="images/home/services-assets.png">
								<h3>Offset Print</h3>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras tempus bibendum venenatis.</p>
							</div>
						</div>
						<div class="col-md-5 hidden-xs">
							<div class="box-service-2">
								<h3>Offset Print</h3>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras tempus bibendum venenatis. Duis in iaculis risus, sed luctus felis. Curabitur id diam eget orci semper facilisis et a nulla. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras tempus bibendum venenatis. Duis in iaculis risus, sed luctus felis. Curabitur id diam eget orci semper facilisis et a nulla. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras tempus bibendum venenatis. Duis in iaculis risus, sed luctus felis. Curabitur id diam eget orci semper facilisis et a nulla.</p>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="col-md-6 col-xs-12">
							<div class="box-service-1">
								<img src="images/home/services-assets.png">
								<h3>Loremp Ipsum</h3>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras tempus bibendum venenatis.</p>
							</div>
						</div>
						<div class="col-md-5 hidden-xs">
							<div class="box-service-2">
								<h3>Loremp Ipsum</h3>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras tempus bibendum venenatis. Duis in iaculis risus, sed luctus felis. Curabitur id diam eget orci semper facilisis et a nulla. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras tempus bibendum venenatis. Duis in iaculis risus, sed luctus felis. Curabitur id diam eget orci semper facilisis et a nulla. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras tempus bibendum venenatis. Duis in iaculis risus, sed luctus felis. Curabitur id diam eget orci semper facilisis et a nulla.</p>
							</div>
						</div>
					</div>
					
					
				</div>

			</div>
		  </div>
	</div>
