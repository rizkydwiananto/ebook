<?php

//WEB TITLE
$title ="Contact Us - Pradaswara Website";
$description ="";
$author ="";

//LAYOUT
$page ="contact_us";

$main_dir = "Contact Us";
$sub_dir = "";
$sub_dir_2 ="";


?>
<!DOCTYPE html>
<html lang="en">
  <head>
	  <?php include"layout/all-head.php"; ?>
  </head>
  <body>
	  
	
<?php 
//HEADER
include"layout/all-header.php";  
include"layout/contact-konten.php";  

  ?>	

	  <?php
//FOOTER
include"layout/all-footer.php";  

	  ?>	
	
	</body>
</html>